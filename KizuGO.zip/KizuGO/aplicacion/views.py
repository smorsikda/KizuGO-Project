from django.shortcuts import render, redirect
from .models import CustomUser

from django.contrib.auth.decorators import login_required
from django.contrib.auth import login, logout, authenticate

# Create your views here.
def main(request):
    return render(request, 'main.html')

def register_view(request):
    if request.user.is_authenticated:
        return redirect('main')
    
    mensaje = None
    
    if request.method == 'POST':
        
        username = request.POST.get('username')
        password = request.POST.get('password')
        print(username,password)
        if not username or not password:
            mensaje = 'Completar todos los requisitos'
        
        try:
            nuevo_usuario = CustomUser.objects.create_user(username=username, password=password)
            login(request, nuevo_usuario)
            return redirect('main')
            
        except Exception as e:
            print('Error al crear usuario: ', e)
    
    return render(request, 'login.html', {
        'mensaje' : mensaje
    })

def login_view(request):
    
    if request.user.is_authenticated:
        return redirect('main')
    
    mensaje = None
    
    if request.method == 'POST':

        username = request.POST.get('username')
        password = request.POST.get('password')
        
        
        if not username or not password:
            mensaje = 'Complete todos los campos'
            
        else:
            
            user = authenticate(request, username=username, password=password)
            
            if user is not None:
                
                login(request, user)
                return redirect('main')
            
            else:
                mensaje = 'Credenciales inválidas'         
    return render(request, 'login.html', {
        'mensaje' : mensaje
    })

def cierre(request):
    logout(request)
    return redirect('main')

def guardar(request):
    if request.method == "POST":
        Nombre = request.POST.get("Nombre")
        Descripcion = request.POST.get("Descripcion")
        Precio = request.POST.get("Precio")
        CategoriaID = request.POST.get("CategoriaID")
        MarcaID = request.POST.get("MarcaID")
        UndMedida = request.POST.get("UndMedida")
        

        