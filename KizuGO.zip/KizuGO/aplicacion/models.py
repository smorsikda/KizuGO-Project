from typing import Any
from django.db import models
from django.contrib.auth.models import AbstractUser

# Create your models here.
class CustomUser(AbstractUser):
    
    telefono = models.CharField(max_length=10)

    def __str__(self) -> str:
        return f'Usuario: {self.username}'

class Departamento(models.Model):
    NombreDepartamento = models.CharField(max_length=50)

    class Meta:
        managed = False
        db_table = "Departamento"

class Municipio(models.Model):
    NombreMunicipio = models.CharField(max_length=50)
    IdDepartamento = models.ForeignKey(Departamento,on_delete=models.CASCADE)

    class Meta:
        managed = False
        db_table = "Municipio"

class Usuario(models.Model):
    Username = models.CharField(max_length=20)
    Contra = models.CharField(max_length=20)

    class Meta:
        managed = False
        db_table = "Usuario"

class Cliente(models.Model):
    NombreCl = models.CharField(max_length=20)
    ApeCl = models.CharField(max_length=20)
    Direccion = models.TextField
    Telefono = models.CharField(max_length=20)
    Email = models.CharField(max_length=25)
    IdMunic = models.ForeignKey(Municipio,on_delete=models.CASCADE)
    UsuarioId = models.ForeignKey(Usuario, on_delete=models.CASCADE)

    class Meta:
        managed = False
        db_table = "Cliente"

class Marca(models.Model):
    NombreMarca = models.CharField(max_length=20)

    class Meta:
        managed = False
        db_table = "Marca"
class Categoria(models.Model):
    NombreCategoria = models.CharField(max_length=20)
    class Meta:
        managed = False
        db_table = "Categoria"

class Producto(models.Model):
    Nombre = models.CharField(max_length=100)
    Descripcion = models.TextField
    Precio = models.DecimalField
    CategoriaID = models.ForeignKey(Categoria, on_delete=models.CASCADE)
    MarcaID = models.ForeignKey
    UndMedida = models.DecimalField

    class Meta:
        managed = False
        db_table = "Producto"

class Compra(models.Model):
    FechaCompra = models.TextField
    ClienteID = models.ForeignKey(Cliente,on_delete=models.CASCADE)

    class Meta:
        managed = False
        db_table = "Compra"

class DetalleCompra(models.Model):
    CompraID = models.ForeignKey(Compra,on_delete=models.CASCADE)
    Cantidad = models.IntegerField
    ProductoID = models.ForeignKey(Producto,on_delete=models.CASCADE)

    class Meta:
        managed = False
        db_table = "DetalleCompra"