from django.urls import path
from . import views

urlpatterns = [
    path('', views.main, name='main'),
    path('login_view/',views.login_view, name = 'login_view'),
    path('login_view/', views.register_view, name='login_view'),  
    path('logout_view/',views.cierre, name='logout_view')
    
]
